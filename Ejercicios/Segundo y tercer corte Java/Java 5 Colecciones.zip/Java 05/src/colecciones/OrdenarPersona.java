/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colecciones;

import java.util.Comparator;

/**
 *
 * @author user
 */
public class  OrdenarPersona implements Comparator<Persona> {
        public  int compare(Persona a, Persona b)
        {
            return   a.getEdad()-b.getEdad();
            //return   b.edad-a.edad;
            //return a.getNombre().compareTo(b.getNombre());

        }
    }
   
