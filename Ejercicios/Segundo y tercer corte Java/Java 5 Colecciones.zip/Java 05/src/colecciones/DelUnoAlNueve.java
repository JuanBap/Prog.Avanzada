/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colecciones;

import java.util.Scanner;
import java.util.Arrays;
import java.util.Collections;

/**
 *
 * @author user
 */
public class DelUnoAlNueve {
     public static void main(String args[]){
        int limite=10;
        
        Integer[] numeros =  new Integer[limite];
        Integer []reverse =  new Integer[limite];
        
        for (int i=0 ;i<limite;i++){
            numeros[i]= i;  
        }
        for (int i=(limite-1) ;i>=0;i--){
            reverse[(limite-1)-i]= numeros[i];  
        }
        
        Arrays.sort(numeros, Collections.reverseOrder());
        
        System.out.println("\n\nDatos almacenados\n\n");
        for (int i=0 ;i<limite;i++){
            System.out.println("numeros["+i+"]:"+numeros[i]);  
        }
        Arrays.sort(reverse);
        System.out.println("\n\nDatos almacenados al reves\n\n");
        for (int i=0 ;i<limite;i++){
            System.out.println("reverse["+i+"]:"+reverse[i]);  
        }
        
        

     }
    
}
