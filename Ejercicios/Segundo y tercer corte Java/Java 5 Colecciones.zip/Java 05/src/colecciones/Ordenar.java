/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colecciones;

import java.util.Arrays;

/**
 *
 * @author user
 */
public class Ordenar {
 
    public static void main(String args[]){
        int arreglo[]={10,5,12,3,8,9};
        
        System.out.println ("Arreglo antes de ordenar");
        for (int i=0;i<arreglo.length;i++)
            System.out.println (arreglo[i]);
        
        System.out.println ("\nArreglo despues de ordenadar");
        Arrays.sort(arreglo);        
        for (int i=0;i<arreglo.length;i++)
            System.out.println (arreglo[i]);
    }
}
