/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polimorfismo;

/**
 *
 * @author user
 */
public class C extends B{
     public int lc;
     public void dummyC(){
         System.out.println ("Dumy C en C");
     }
}
