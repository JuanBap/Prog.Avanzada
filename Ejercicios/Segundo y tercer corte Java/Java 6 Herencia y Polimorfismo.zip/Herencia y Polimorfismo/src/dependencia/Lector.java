/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dependencia;

/**
 *
 * @author user
 */
public class Lector {
    // ...
    
    // Método que utiliza un objeto de la clase Libro
    public void leerLibro(Libro libro) {
        // Código para leer el libro...
    }
    
    // ...
}


