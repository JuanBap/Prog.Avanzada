/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstractas.geometria;

/**
 *
 * @author user
 */
public class Cuadrado extends Figura {
    
     public  double area(double lado){
        return lado*lado;
    }
    
    
}
