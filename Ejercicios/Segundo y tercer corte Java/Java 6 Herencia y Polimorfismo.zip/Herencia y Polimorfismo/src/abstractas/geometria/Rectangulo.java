/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstractas.geometria;

/**
 *
 * @author user
 */
public class Rectangulo extends Figura {
    
     public  double area(double lado){
        return 0;
    }
    
        public  double area(double l1, double l2){
        return l1*l2;
    }
     
}
