/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstractas.geometria;

/**
 *
 * @author user
 */
public class Circulo extends Figura {
    public  double area(double radio){
        return 3.14*Math.pow(radio,2);
    }
    
    
}
