/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atributos;

/**
 *
 * @author user
 */
public class Split {
    
    public static void main (String args[]){
        
        int n=0;
        String palabras[];
        String cadena= "Esta es una cadena de palabras";
        palabras= cadena.split(" ");
        n=palabras.length;
        for (int i=0; i<n;i++){
            System.out.format ("Palabra [%d]:%s \n",i,palabras[i]);
        }
        
        
       
        String strNumero="100,200,300,400";
        String numeros[];
        numeros= strNumero.split(",");
        n=numeros.length;
        for (int i=0; i<n;i++){
            System.out.format ("Numero [%d]:%s \n",i,numeros[i]);
        }
        
    }
    
}
